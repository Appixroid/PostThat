java -jar PostThat.jar
